<?php
   $name=$_POST['name'];
   $dob=$_POST['dob'];
   $age=$_POST['age'];
   $gender=$_POST['gender'];
   $contact=$_POST['contact'];
   $city=$_POST['city'];
   $state=$_POST['state'];
   $country=$_POST['country'];
   $email=$_POST['email'];
 $manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
 $databaseName = "GuviTask";
 $collectionName = "Profile";
 $collection = $databaseName . "." . $collectionName;
 $filter = ['email' => $email];
 $options = ['limit' => 1];
 $query = new MongoDB\Driver\Query($filter, $options);
 $result = $manager->executeQuery($collection, $query)->toArray();
 if (count($result) === 1) {
       $bulk = new MongoDB\Driver\BulkWrite();
       $bulk->update(
        ['email' => $email],
      ['$set' => ['name' => $name,
         'dob' => $dob,
         'age' => $age,
         'gender' => $gender,
         'contact' => $contact,
         'city' => $city,
         'state' => $state,
         'country' => $country]]
    );
    $result = $manager->executeBulkWrite($collection, $bulk);
     echo "Profile Updated Successfully.";
 }
 else {
    $bulk = new MongoDB\Driver\BulkWrite;
    $document1 = ['name' => $name,
    'dob' => $dob,
    'age' => $age,
    'gender' => $gender,
    'contact' => $contact,
    'city' => $city,
    'state' => $state,
    'country' => $country,
    'email' => $email];
$bulk->insert($document1);
$result = $manager->executeBulkWrite($collection, $bulk);
echo "Profile Saved Successfully.";
}
?>

