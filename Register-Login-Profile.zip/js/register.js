function submit(){
	event.preventDefault();
  var username = document.getElementById("username").value;
  var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
  if(isEmpty(username)|| isEmpty(email)|| isEmpty(password)){
        alert("No fields to be left blank");
    }
  if (username.length < 4 ) {
    alert("Username must be at least 4 characters long");
    return;
  }
  if (username.length > 20) {
    alert("Username must be less than 20 characters");
    return;
  }
  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email.match(emailPattern)) {
    alert("Please enter a valid email address");
    return;
  }
  if (password.length < 6) {
    alert("Password must be at least 6 characters long");
    return;
  }
  if (password.length > 20) {
    alert("Password must be less than 20 characters");
    return;
  }
  $.ajax({
    url: "/GUVI TASK/php/register.php",
    type: "POST",
    dataType: 'text',
    data: {
      username: username,
      email: email,
      password: password
    },
    success: function(response) {
      alert(response);
      window.location.href = "/GUVI TASK/login.html";
    },
    error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
    }
  });
}
function isEmpty(str) {
    return (!str || str.length === 0 );
}
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}